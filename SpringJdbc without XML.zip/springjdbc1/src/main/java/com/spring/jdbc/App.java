package com.spring.jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.jdbc.dao.StudentDao;
import com.spring.jdbc.entities.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "My Program started..............." );
        
        // spring jdbc=>  JdbcTemplate
        
        ApplicationContext context= new ClassPathXmlApplicationContext("com/spring/jdbc/config.xml");
        
        StudentDao studentDao = context.getBean("studentDao", StudentDao.class);
       
        // insert 
        
//        Student student= new Student();
//        student.setId(456);
//        student.setName("Sam karran");
//        student.setCity("norway");
//        int result=studentDao.insert(student);       
//        System.out.println("student added "+result);
        
        
        
        
        // change
        
//        Student student = new Student();
//        student.setId(666);
//        student.setName("viraj");
//        student.setCity("kalegaon");
//        int result= studentDao.change(student);
//        System.out.println("data change successfully");
        
        
        
        // delete
        
        
//        int result=studentDao.delete(222);
//        System.out.println("deleted "+result);
        
        
        
        //selecting single object using spring jdbc
        
        
//        Student student = studentDao.getStudent(456);
//        System.out.println(student);
        
        
        
        // selecting multiple object using spring jdbc
        
        
        List<Student> student= studentDao.getAllStudent();
        System.out.println(student);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
